# LexiFix — Hybrid AI Spell + Context + Grammar Engine

LexiFix is an advanced text-cleaning system that blends traditional spell checking with
modern AI language modeling. Unlike basic spellcheckers that only compare words to a
dictionary, LexiFix evaluates meaning and sentence context using BERT and optionally
applies grammar refinement using FLAN-T5 when a GPU is available.

---

##What Makes LexiFix Different?

| Component | Purpose |
|----------|---------|
| PySpellChecker | Detects and corrects true spelling mistakes |
| BERT (Masked Language Model) | Predicts words that best fit the sentence context |
| POS Matching | Rejects corrections that change meaning (noun → verb etc.) |
| Normalization | Handles elongated words ("soooo" → "soo") and preserves punctuation |
| FLAN-T5 Grammar (GPU only) | Optional final grammar rephrase / polishing |

LexiFix avoids destructive substitutions (e.g., history → chemistry) and only accepts
contextual changes when meaning stays intact.

---

##Features

- Dictionary-based spelling correction
- Context-aware correction from BERT
- Meaning preservation through part-of-speech filtering
- Confidence scores per correction
- Capitalization and punctuation preserved
- Optional grammar synthesis (GPU only)
- Colab and local deployment supported

---

##Installation

Clone the repository and install dependencies:

Steps:
python -m venv venv

# Windows:
venv\Scripts\activate

# macOS/Linux:
source venv/bin/activate

pip install -r requirements.txt
python app.py

(needed for local deploy)
Run PowerShell as Administrator and enter:
Set-ExecutionPolicy RemoteSigned 

##
The interface will launch at:http://127.0.0.1:7860

Paste or type any paragraph to receive:
- corrected text
- highlighted corrections
- correction list with confidence rating



##License

Free for all use


##Acknowledgments

This project uses pretrained open-source models from:
- Hugging Face  
- PySpellChecker  
- NLTK WordNet  

All credit to their respective authors and contributors.





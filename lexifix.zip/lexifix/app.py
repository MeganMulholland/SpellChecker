import gradio as gr
from AdvancedSpellCheck import AdvancedSpellChecker

checker = None

def run_system():
    global checker
    if checker is None:
        checker = AdvancedSpellChecker()
    return checker

def run_spellcheck(text):
    if not text.strip():
        return ("Please enter text.", "", "", "")

    engine = run_system()
    result = engine.spell_check_advanced(text)

    original = result["original"]
    corrected = result["corrected"]
    highlighted = result["highlighted"]
    grammar_final = result.get("corrected_grammar", corrected)

    # summary of changes
    details_lines = []
    for d in result["details"]:
        before = d["original"]
        after = d.get("recommended", d["basic_correction"])
        conf = d.get("confidence", "")
        details_lines.append(f"{before}  ➜  {after}   ({conf})")

    return original, corrected, grammar_final, "\n".join(details_lines)

with gr.Blocks(title="LexiFix Spell + Context + Grammar Engine") as demo:

    gr.Markdown("# **LexiFix** — Hybrid AI Spell + Context + Grammar Engine")
    gr.Markdown("Enter any text to receive AI-powered correction while preserving meaning.")

    text_input = gr.Textbox(
        label="Input text",
        placeholder="Paste or type a paragraph...",
        lines=8
    )

    run_btn = gr.Button("Run Spell + Context + Grammar")

    original_box = gr.Textbox(label="Original", lines=6)
    corrected_box = gr.Textbox(label="Corrected (Spell + Context)", lines=6)
    grammar_box = gr.Textbox(label="Final (Grammar-Polished if GPU Available)", lines=6)
    details_box = gr.Textbox(label="Correction Details", lines=10)

    run_btn.click(
        run_spellcheck,
        inputs=[text_input],
        outputs=[original_box, corrected_box, grammar_box, details_box]
    )

demo.launch()

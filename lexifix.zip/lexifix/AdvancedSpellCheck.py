import re
import torch
from transformers import AutoTokenizer, AutoModelForMaskedLM, pipeline
from spellchecker import SpellChecker
from difflib import SequenceMatcher

import nltk
from nltk.corpus import wordnet as wn

try:
    nltk.data.find("corpora/wordnet")
except LookupError:
    nltk.download("wordnet")


def normalize_elongated(word):
    return re.sub(r"(.)\1{2,}", r"\1\1", word)


def get_pos_category(word):
    synsets = wn.synsets(word)
    if not synsets:
        return None
    pos = synsets[0].pos()
    return pos if pos in ["n", "v", "a", "r"] else None


class AdvancedSpellChecker:
    def __init__(self):
        self.spell = SpellChecker()
        self.custom_words = set()

        print("Loading language model...")
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        print(f"Device: {self.device.upper()}")

        try:
            self.model_name = "bert-large-uncased"
            self.tokenizer = AutoTokenizer.from_pretrained(self.model_name)
            self.model = AutoModelForMaskedLM.from_pretrained(self.model_name).to(self.device)
            print("Loaded BERT-Large")
        except Exception:
            self.model_name = "bert-base-uncased"
            self.tokenizer = AutoTokenizer.from_pretrained(self.model_name)
            self.model = AutoModelForMaskedLM.from_pretrained(self.model_name).to(self.device)
            print("Loaded BERT-Base fallback")

        self.model.eval()

        # Grammar model (GPU optional)
        if self.device == "cuda":
            try:
                self.grammar_checker = pipeline(
                    "text2text-generation",
                    model="pszemraj/flan-t5-base-grammar-synthesis",
                    device=0,
                )
                print("Grammar enabled (FLAN-T5-Base)")
            except Exception:
                self.grammar_checker = None
                print("Grammar unavailable")
        else:
            self.grammar_checker = None
            print("Grammar disabled on CPU")

    def add_to_custom_dict(self, word):
        self.custom_words.add(word.lower())

    def similarity(self, a, b):
        return SequenceMatcher(None, a.lower(), b.lower()).ratio()

    def get_contextual_suggestions(self, sentence, word_idx, original_word):
        words = sentence.split()
        masked_words = words.copy()
        masked_words[word_idx] = "[MASK]"
        masked_sentence = " ".join(masked_words)

        try:
            inputs = self.tokenizer(masked_sentence, return_tensors="pt").to(self.device)
            with torch.no_grad():
                outputs = self.model(**inputs)

            mask_token_index = (inputs.input_ids == self.tokenizer.mask_token_id).nonzero(as_tuple=True)[1]
            if len(mask_token_index) == 0:
                return []

            logits = outputs.logits[0, mask_token_index, :]
            top_tokens = torch.topk(logits, 20, dim=1).indices[0].tolist()

            suggestions = []
            for tok in top_tokens:
                decoded = self.tokenizer.decode([tok]).strip()
                if not decoded or decoded.startswith("[") or decoded.startswith("##") or not decoded.isalpha():
                    continue
                merged = self.tokenizer.convert_tokens_to_string([self.tokenizer.convert_ids_to_tokens(tok)])
                merged = merged.replace(" ", "")
                suggestions.append(merged if merged.isalpha() else decoded)

            return list(dict.fromkeys(suggestions))[:10]
        except Exception:
            return []

    def spell_check_basic(self, text):
        words = text.split()
        issues = []
        for idx, word in enumerate(words):
            clean = re.sub(r"[^\w]", "", word)
            lower = clean.lower()
            if not lower or lower in self.custom_words or not any(c.isalpha() for c in lower):
                continue
            if lower not in self.spell:
                corrected = self.spell.correction(lower)
                candidates = list(self.spell.candidates(lower)) if self.spell.candidates(lower) else []
                issues.append({
                    "index": idx,
                    "original": word,
                    "clean_original": clean,
                    "basic_correction": corrected if corrected else clean,
                    "basic_suggestions": candidates,
                })
        return issues

    def spell_check_advanced(self, text):
        words = [normalize_elongated(w) for w in text.split()]
        text = " ".join(words)
        issues = self.spell_check_basic(text)

        for issue in issues:
            contextual_sugs = self.get_contextual_suggestions(text, issue["index"], issue["clean_original"])
            issue["contextual_suggestions"] = contextual_sugs

            original = issue["clean_original"].lower()
            basic = (issue["basic_correction"] or "").lower()

            best_contextual = None
            best_score = 0
            for sug in contextual_sugs[:5]:
                score = self.similarity(original, sug)
                if score > best_score:
                    best_score = score
                    best_contextual = sug

            if original != basic:
                replacement = issue["basic_correction"]
            elif best_contextual and best_score >= 0.88 and best_contextual.lower() != original:
                replacement = best_contextual
            else:
                replacement = original

            orig_pos = get_pos_category(original)
            cand_pos = get_pos_category(replacement)
            if orig_pos and cand_pos and orig_pos != cand_pos:
                replacement = original

            issue["recommended"] = replacement
            issue["confidence"] = "high" if replacement != original else "low"

        return self.format_results(text, issues)

    def apply_grammar_if_available(self, corrected_text):
        if not self.grammar_checker:
            return corrected_text
        try:
            output = self.grammar_checker(corrected_text, max_length=512, num_beams=4)
            return output[0]["generated_text"]
        except Exception:
            return corrected_text

    def apply_cap(self, original, replacement):
        if original.isupper():
            return replacement.upper()
        if original.istitle():
            return replacement.capitalize()
        return replacement

    def format_results(self, text, issues):
        words = text.split()
        corrected = words.copy()
        highlighted = words.copy()

        for issue in issues:
            i = issue["index"]
            original = words[i]
            replacement = issue.get("recommended", issue["basic_correction"])

            prefix = re.match(r"^\W*", original).group()
            suffix = re.search(r"\W*$", original).group()

            replacement = self.apply_cap(original.strip("".join(set(prefix + suffix))), replacement)
            corrected[i] = f"{prefix}{replacement}{suffix}"

            if replacement.lower() != issue["clean_original"].lower():
                highlighted[i] = f"**{prefix}{replacement}{suffix}**"
            else:
                highlighted[i] = f"{prefix}{replacement}{suffix}"

        corrected_text = " ".join(corrected)
        grammar_final = self.apply_grammar_if_available(corrected_text)

        return {
            "original": text,
            "corrected": corrected_text,
            "corrected_grammar": grammar_final,
            "highlighted": " ".join(highlighted),
            "corrections": [(i["original"], i.get("recommended", i["basic_correction"])) for i in issues],
            "details": issues,
        }
